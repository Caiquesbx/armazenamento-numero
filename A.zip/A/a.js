function storage() {
    let numero = document.getElementById("numeros").value;
    localStorage.setItem("numero", numero);
    alert("Foi!");
}
